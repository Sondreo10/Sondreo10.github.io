const main = document.querySelector("main");


function random() {
  Math.random(9(+1))
}
