var array = ["Lisa", "Ole", "Daniel", "Tom", "Ferdinand", "Kriss"];
